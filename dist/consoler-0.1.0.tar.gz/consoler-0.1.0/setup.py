# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['consoler']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'consoler',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'Hactar',
    'author_email': 'systems@hactar.is',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/hactar-is/consoler',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
