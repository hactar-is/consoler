__version__ = '0.1.0'

from .console import Logger


logger = Logger()
console = logger
